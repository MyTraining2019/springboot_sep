package org.cap.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class LoginController {

	@RequestMapping("/validateLogin")
	public ModelAndView validateUser(@RequestParam("userName") String userName,
			@RequestParam("userPwd") String userPwd) {
		
		String viewPage="success";
		
		
		if(userName.equalsIgnoreCase("tom") && 
				userPwd.equals("tom123")) {
			return new ModelAndView(viewPage, "user", userName);
		}
		
		return new ModelAndView("redirect:/");
	}
}
