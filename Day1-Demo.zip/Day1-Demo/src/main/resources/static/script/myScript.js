function validateUser(){
	var flag=false;
	
	var usrName=f1.userName.value;
	var userPwd=f1.userPwd.value;
	
	//alert(usrName);
	
	if(usrName==null || usrName==""){
		document.getElementById('usrErrMsg').innerHTML="* Please enter userName.";
		document.getElementById('pwdErrMsg').innerHTML="";
	}else if(userPwd==null || userPwd==""){
		document.getElementById('pwdErrMsg').innerHTML="* Please enter Password.";
		document.getElementById('usrErrMsg').innerHTML="";
	}
	else{
		flag=true;
	}
	
	return flag;
}