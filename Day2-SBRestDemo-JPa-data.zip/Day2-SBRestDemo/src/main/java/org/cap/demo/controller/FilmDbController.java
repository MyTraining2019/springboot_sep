package org.cap.demo.controller;

import java.util.List;

import org.cap.demo.model.Film;
import org.cap.demo.service.IFilmService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v2")
public class FilmDbController {

	@Autowired
	private IFilmService filmDbService;
	
	@GetMapping("/films")
	public ResponseEntity<List<Film>> getAllFilms() {
		List<Film> films= filmDbService.getAllFilms();
		
		if(films.isEmpty() || films==null) {
			return new ResponseEntity("Sorry! Film details not available!",HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Film>>(films, HttpStatus.OK);
		
	}
	
	
	@GetMapping("/films/{filmId}")
	public ResponseEntity<Film> searchFilmDetails(
			@PathVariable("filmId")Long filmId){
		Film film= filmDbService.searchFilm(filmId);
		
		if(film==null)
			return new ResponseEntity
					("Sorry! Film Id does not exists!",HttpStatus.NOT_FOUND);
		
		return new ResponseEntity<Film>(film,HttpStatus.OK);
	}
	
	
	
	@DeleteMapping("/films/{filmId}")
	public ResponseEntity<List<Film>> deleteFilm(
			@PathVariable("filmId") Long filmId){
		
		List<Film> films= filmDbService.deleteFilm(filmId);
		if(films==null || films.isEmpty())
			return new ResponseEntity
					("Sorry! Film Id does not exists!",HttpStatus.NOT_FOUND);
		
		
		return new ResponseEntity<List<Film>>(films, HttpStatus.OK);
		
	}
	
	
	
	
	
	
	
	@PostMapping("/films")
	public ResponseEntity<List<Film>> createFilm(@RequestBody Film film){
		List<Film> films= filmDbService.createFilm(film);
		if(films.isEmpty() || films==null) {
			return new ResponseEntity("Sorry! Film details not available!",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Film>>(films, HttpStatus.OK);
	}
	
	@PutMapping("/films")
	public ResponseEntity<List<Film>> updateFilms(@RequestBody Film film){
		List<Film> films= filmDbService.updateFilm(film);
		
		
		return new ResponseEntity<List<Film>>(films, HttpStatus.OK);
	}
	
	
	
	
}
