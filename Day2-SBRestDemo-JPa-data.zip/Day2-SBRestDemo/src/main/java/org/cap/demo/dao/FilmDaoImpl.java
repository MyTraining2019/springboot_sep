package org.cap.demo.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

import org.cap.demo.model.Film;
import org.springframework.stereotype.Repository;



@Repository("filmDao")
public class FilmDaoImpl implements IFilmDao {

	private static AtomicLong filmId=new AtomicLong(1000);
	private static List<Film> films=dummyDbFilms();
	
	private static List<Film> dummyDbFilms(){
		List<Film> films=new ArrayList<>();
		films.add(new Film(filmId.incrementAndGet(), "Tom and Jerry", new Date(2012-1900, 11, 23), 23000, "tom@gmail.com"));
		films.add(new Film(filmId.incrementAndGet(), "RIO2", new Date(2018-1900, 11, 3), 340000, "rio2@gmail.com"));
		films.add(new Film(filmId.incrementAndGet(), "Jungle Book", new Date(), 90000, "junglBook@gmail.com"));
		films.add(new Film(filmId.incrementAndGet(), "Forest Hunt", new Date(2019-1900, 1, 12), 78000, "hunt@gmail.com"));
		films.add(new Film(filmId.incrementAndGet(), "RIO1", new Date(), 45000, "rio1@gmail.com"));
		return films;
	}

	@Override
	public List<Film> getAllFilms() {
			return films;
	}

	@Override
	public Film searchFilm(Long filmId) {
		for(Film film:films) {
			if(film.getFilmId()==filmId)
				return film;
		}
		return null;
	}

	@Override
	public List<Film> deleteFilm(Long filmId) {
		boolean flag=false;
		Iterator<Film> iterator= films.iterator();
		
		while(iterator.hasNext()) {
			Film film= iterator.next();
			if(film.getFilmId()==filmId) {
				flag=true;
				iterator.remove();
				break;
			}
		}
		
		if(flag)
			return films;
		else
			return null;
	}

	@Override
	public List<Film> createFilm(Film film) {
		films.add(film);
		return films;
	}

	@Override
	public List<Film> updateFilm(Film film) {
		boolean flag=false;
		java.util.ListIterator<Film> iterator= films.listIterator();
		
		while(iterator.hasNext()) {
			Film film1= iterator.next();
			if(film1.getFilmId()==film.getFilmId()) {
				flag=true;
				iterator.set(film);
				break;
			}
		}
		
		if(!flag)
		films.add(film);
			
		return films;
		
	}
	
}
