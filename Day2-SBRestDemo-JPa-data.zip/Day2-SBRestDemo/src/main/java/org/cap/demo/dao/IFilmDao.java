package org.cap.demo.dao;

import java.util.List;

import org.cap.demo.model.Film;

public interface IFilmDao {
	
	public List<Film> getAllFilms();

	public Film searchFilm(Long filmId);

	public List<Film> deleteFilm(Long filmId);

	public List<Film> createFilm(Film film);

	public List<Film> updateFilm(Film film);

}
