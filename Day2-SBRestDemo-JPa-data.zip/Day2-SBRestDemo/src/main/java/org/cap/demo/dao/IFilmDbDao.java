package org.cap.demo.dao;

import org.cap.demo.model.Film;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository("filmDbDao")
public interface IFilmDbDao extends JpaRepository<Film, Long>{

}
