package org.cap.demo.dao;

import java.util.List;

import org.cap.demo.model.Film;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;


@Repository("filmDbDao")
public interface IFilmDbDao extends JpaRepository<Film, Long>{
	
	
	@Query("from Film f where f.rentalCost>=:rentalCost and f.filmId>=:filmId")
	public List<Film> findAllFilms(@Param("rentalCost")double rentalCost,
			@Param("filmId")long filmId);
	
	
	public List<Film> findByProducerEmail(String producerEmail);
	
	//select * from film where rentalcost=? or filmId=?;
	public List<Film> findByRentalCostOrFilmId(double rentalCost,long filmId);
}
