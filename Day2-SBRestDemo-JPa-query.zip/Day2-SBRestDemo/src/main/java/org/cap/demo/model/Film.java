package org.cap.demo.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@JsonIgnoreProperties(value= {"handler","hibernateLazyInitializer"})
public class Film {
	@Id
	private long filmId;
	private String filmName;
	
	@JsonFormat(pattern="dd-MMM-yyyy")
	private Date relaseDate;
	
	private double rentalCost;
	private String producerEmail;
	
	
	public long getFilmId() {
		return filmId;
	}
	public void setFilmId(long filmId) {
		this.filmId = filmId;
	}
	public String getFilmName() {
		return filmName;
	}
	public void setFilmName(String filmName) {
		this.filmName = filmName;
	}
	public Date getRelaseDate() {
		return relaseDate;
	}
	public void setRelaseDate(Date relaseDate) {
		this.relaseDate = relaseDate;
	}
	public double getRentalCost() {
		return rentalCost;
	}
	public void setRentalCost(double rentalCost) {
		this.rentalCost = rentalCost;
	}
	
	
	
	public String getProducerEmail() {
		return producerEmail;
	}
	public void setProducerEmail(String producerEmail) {
		this.producerEmail = producerEmail;
	}
	public Film() {
		
	}
	@Override
	public String toString() {
		return "Film [filmId=" + filmId + ", filmName=" + filmName + ", relaseDate=" + relaseDate + ", rentalCost="
				+ rentalCost + ", producer_email=" + producerEmail + "]";
	}
	public Film(long filmId, String filmName, Date relaseDate, double rentalCost, String producerEmail) {
		super();
		this.filmId = filmId;
		this.filmName = filmName;
		this.relaseDate = relaseDate;
		this.rentalCost = rentalCost;
		this.producerEmail = producerEmail;
	}
	
	

}
