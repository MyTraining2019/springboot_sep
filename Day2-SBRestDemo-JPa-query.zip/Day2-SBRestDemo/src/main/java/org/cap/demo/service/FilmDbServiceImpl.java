package org.cap.demo.service;

import java.util.List;

import org.cap.demo.dao.IFilmDbDao;
import org.cap.demo.model.Film;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("filmDbService")
public class FilmDbServiceImpl implements IFilmService {
	
	@Autowired
	private IFilmDbDao filmDbDao;

	@Override
	public List<Film> getAllFilms() {
		
		return filmDbDao.findAll();
	}

	@Override
	public Film searchFilm(Long filmId) {
		
		return filmDbDao.getOne(filmId);
	}

	@Override
	public List<Film> deleteFilm(Long filmId) {
		filmDbDao.deleteById(filmId);
		return filmDbDao.findAll();
	}

	@Override
	public List<Film> createFilm(Film film) {
		filmDbDao.save(film);
		return filmDbDao.findAll();
	}

	@Override
	public List<Film> updateFilm(Film film) {
		filmDbDao.save(film);
		return filmDbDao.findAll();
	}

	@Override
	public List<Film> findByProducer_email(String producer_email) {
		
		return filmDbDao.findByProducerEmail(producer_email);
	}

	@Override
	public List<Film> findByRentalCostOrFilmId(double rentalCost, long filmId) {
		
		return filmDbDao.findByRentalCostOrFilmId(rentalCost, filmId);
	}

	@Override
	public List<Film> findAllFilms(double rentalCost, long filmId) {
	
		return filmDbDao.findAllFilms(rentalCost, filmId);
	}

}
