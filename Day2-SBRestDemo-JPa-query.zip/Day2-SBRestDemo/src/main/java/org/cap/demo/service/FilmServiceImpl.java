package org.cap.demo.service;

import java.util.List;

import org.cap.demo.dao.IFilmDao;
import org.cap.demo.model.Film;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service("filmService")
public abstract class FilmServiceImpl implements IFilmService{

	@Autowired
	private IFilmDao filmDao;
	
	@Override
	public List<Film> getAllFilms() {
		
		return filmDao.getAllFilms();
	}

	@Override
	public Film searchFilm(Long filmId) {
		
		return filmDao.searchFilm(filmId);
	}

	@Override
	public List<Film> deleteFilm(Long filmId) {
		
		return filmDao.deleteFilm(filmId);
	}

	@Override
	public List<Film> createFilm(Film film) {
		
		return filmDao.createFilm(film);
	}

	@Override
	public List<Film> updateFilm(Film film) {
		
		return filmDao.updateFilm(film);
	}

}
