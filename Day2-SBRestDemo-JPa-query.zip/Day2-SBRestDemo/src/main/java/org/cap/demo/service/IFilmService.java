package org.cap.demo.service;

import java.util.List;

import org.cap.demo.model.Film;

public interface IFilmService {
	public List<Film> getAllFilms();

	public Film searchFilm(Long filmId);

	public List<Film> deleteFilm(Long filmId);

	public List<Film> createFilm(Film film);

	public List<Film> updateFilm(Film film);
	public List<Film> findByProducer_email(String producer_email);
	
	public List<Film> findByRentalCostOrFilmId(double rentalCost,long filmId);
	
	public List<Film> findAllFilms(double rentalCost,long filmId);
	
}
