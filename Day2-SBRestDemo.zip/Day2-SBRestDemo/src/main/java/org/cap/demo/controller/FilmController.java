package org.cap.demo.controller;

import java.util.List;

import org.cap.demo.model.Film;
import org.cap.demo.service.IFilmService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1")
public class FilmController {
	
	@Autowired
	private IFilmService filmService;
	
	@GetMapping("/films")
	public ResponseEntity<List<Film>> getAllFilms() {
		List<Film> films= filmService.getAllFilms();
		
		if(films.isEmpty() || films==null) {
			return new ResponseEntity("Sorry! Film details not available!",HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Film>>(films, HttpStatus.OK);
		
	}

}










