package org.cap.demo.dao;

import java.util.List;

import org.cap.demo.model.Film;

public interface IFilmDao {
	
	public List<Film> getAllFilms();

}
