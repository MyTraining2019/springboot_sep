package org.cap.demo.model;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class Film {
	
	private long filmId;
	private String filmName;
	
	@JsonFormat(pattern="dd-MMM-yyyy")
	private Date relaseDate;
	
	private double rentalCost;
	private String producer_email;
	
	
	public long getFilmId() {
		return filmId;
	}
	public void setFilmId(long filmId) {
		this.filmId = filmId;
	}
	public String getFilmName() {
		return filmName;
	}
	public void setFilmName(String filmName) {
		this.filmName = filmName;
	}
	public Date getRelaseDate() {
		return relaseDate;
	}
	public void setRelaseDate(Date relaseDate) {
		this.relaseDate = relaseDate;
	}
	public double getRentalCost() {
		return rentalCost;
	}
	public void setRentalCost(double rentalCost) {
		this.rentalCost = rentalCost;
	}
	public String getProducer_email() {
		return producer_email;
	}
	public void setProducer_email(String producer_email) {
		this.producer_email = producer_email;
	}
	public Film(long filmId, String filmName, Date relaseDate, double rentalCost, String producer_email) {
		super();
		this.filmId = filmId;
		this.filmName = filmName;
		this.relaseDate = relaseDate;
		this.rentalCost = rentalCost;
		this.producer_email = producer_email;
	}
	public Film() {
		
	}
	@Override
	public String toString() {
		return "Film [filmId=" + filmId + ", filmName=" + filmName + ", relaseDate=" + relaseDate + ", rentalCost="
				+ rentalCost + ", producer_email=" + producer_email + "]";
	}
	
	

}
