package org.cap.demo.service;

import java.util.List;

import org.cap.demo.dao.IFilmDao;
import org.cap.demo.model.Film;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service("filmService")
public class FilmServiceImpl implements IFilmService{

	@Autowired
	private IFilmDao filmDao;
	
	@Override
	public List<Film> getAllFilms() {
		
		return filmDao.getAllFilms();
	}

}
