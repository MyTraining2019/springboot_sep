package org.cap.demo.service;

import java.util.List;

import org.cap.demo.model.Film;

public interface IFilmService {
	public List<Film> getAllFilms();
}
